function data = robot_sim_server(command)


%obstacle = [7 8 10 11];
%obstacle = [3 9 12 15];
%obstacle = [5 7 9 15];
%obstacle = [2 3 6 15];
%obstacle = [12 13 14 5];
%%%
persistent obstacle
if isempty(obstacle)
    obstacle = [12 13 14 5];
end

%%%

persistent num_moves; 
persistent pos;
persistent dir; 

if isempty(pos)||isempty(dir)
    pos = 0;
    dir = 0;
    num_moves = 0; 
end 

switch command
    
    case "sensor_read"
         data=sensor_read(pos,dir,obstacle); 
         
    case "move 0"                   % turn left
        
        data = move(pos,dir,0);
        pos = data(1);
        dir = data(2);
        num_moves = num_moves + 1; 
        
    case "move 1"                   % move straight 
        
        data = move(pos,dir,1);
        pos = data(1);
        dir = data(2);
        num_moves = num_moves + 1; 
        
        
    case "move 2"                   % turn right
        data = move(pos,dir,2);
        pos = data(1);
        dir = data(2);
        num_moves = num_moves + 1; 
        
    case "status"
        data = [pos dir num_moves];
    case "remove_obstacle"
    if nargin > 1
        obstacle = setdiff(obstacle, command{2});
    end
    
end 

return