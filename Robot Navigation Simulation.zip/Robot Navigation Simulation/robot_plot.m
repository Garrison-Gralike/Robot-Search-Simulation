function robot_plot(pos, dir, obstacle)
    clf;  % Clear previous plot

    % Calculate row and column for the robot's current position
    row = floor(pos / 4);
    col = mod(pos, 4);

    % Draw 4x4 grid
    for i = 0:3
        for j = 0:3
            rectangle('Position', [i, j, 1, 1], 'FaceColor', [1 1 1], 'EdgeColor', 'k');
        end
    end

    % Draw obstacles
    for i = 1:length(obstacle)
        obs = obstacle(i);
        if obs >= 0 && obs <= 15
            obs_row = floor(obs / 4);
            obs_col = mod(obs, 4);
            rectangle('Position', [obs_col + 0.1, obs_row + 0.1, 0.8, 0.8], ...
                      'FaceColor', [0.5 0.67 0.95], 'EdgeColor', 'b');
        end
    end

    % Add grid cell numbers (labels)
    label = 0;
    for r = 0:3
        for c = 0:3
            text(c + 0.5, r + 0.5, num2str(label), ...
                 'HorizontalAlignment', 'center', ...
                 'VerticalAlignment', 'middle', ...
                 'FontSize', 10, 'Color', 'k');
            label = label + 1;
        end
    end

    % Draw the robot
    if dir == 0  % Up
        rectangle('Position', [col+0.2, row+0.3, 0.1, 0.4], 'FaceColor', [1 0 0])
        rectangle('Position', [col+0.3, row+0.2, 0.4, 0.6], 'FaceColor', [0.5 0.5 0.5])
        rectangle('Position', [col+0.7, row+0.3, 0.1, 0.4], 'FaceColor', [1 0 0])
        rectangle('Position', [col+0.4, row+0.7, 0.2, 0.1], 'FaceColor', [1 1 0])
    elseif dir == 1  % Left
        rectangle('Position', [col+0.3, row+0.2, 0.4, 0.1], 'FaceColor', [1 0 0])
        rectangle('Position', [col+0.2, row+0.3, 0.6, 0.4], 'FaceColor', [0.5 0.5 0.5])
        rectangle('Position', [col+0.3, row+0.7, 0.4, 0.1], 'FaceColor', [1 0 0])
        rectangle('Position', [col+0.2, row+0.4, 0.1, 0.2], 'FaceColor', [1 1 0])
    elseif dir == 2  % Down
        rectangle('Position', [col+0.2, row+0.3, 0.1, 0.4], 'FaceColor', [1 0 0])
        rectangle('Position', [col+0.3, row+0.2, 0.4, 0.6], 'FaceColor', [0.5 0.5 0.5])
        rectangle('Position', [col+0.7, row+0.3, 0.1, 0.4], 'FaceColor', [1 0 0])
        rectangle('Position', [col+0.4, row+0.2, 0.2, 0.1], 'FaceColor', [1 1 0])
    elseif dir == 3  % Right
        rectangle('Position', [col+0.3, row+0.2, 0.4, 0.1], 'FaceColor', [1 0 0])
        rectangle('Position', [col+0.2, row+0.3, 0.6, 0.4], 'FaceColor', [0.5 0.5 0.5])
        rectangle('Position', [col+0.3, row+0.7, 0.4, 0.1], 'FaceColor', [1 0 0])
        rectangle('Position', [col+0.7, row+0.4, 0.1, 0.2], 'FaceColor', [1 1 0])
    end

    % Final plot settings
    axis([0 4 0 4]);
    axis equal;
    set(gca, 'XTick', []);
    set(gca, 'YTick', []);
end
