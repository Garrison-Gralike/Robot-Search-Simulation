function [target_dir, turn_cmd] = calculate_turn(pos, current_dir, next_pos)
    delta = next_pos - pos;
    switch delta
        case 1
            target_dir = 3; % right
        case -1
            target_dir = 1; % left
        case 4
            target_dir = 0; % up
        case -4
            target_dir = 2; % down
        otherwise
            target_dir = current_dir;
    end

    diff = mod(target_dir - current_dir, 4);
    if diff == 1
        turn_cmd = 2; % right
    elseif diff == 3
        turn_cmd = 0; % left
    else
        turn_cmd = 1; % forward (shouldn't be called here)
    end
end
