% Demo1.m
% =============================================================================================
% File Name    : Demo1.m
% Author       : Garrison Gralike and Alejandro Palacio C
% Date Written : 06/27/2025
% Course       : EEL4930
% Project Name : Mini Project 1, Robot Navigation
% Purpose      : Simulates a robot navigating a 4x4 grid to detect and push
%                4 objects out of bounds using a combination of sensor data,
%                A* pathfinding, and object management logic.
% =============================================================================================

% ---------------------------------------------------------------------------------------------
% Function     : Demo1
% Purpose      : Main control loop for the robot simulation. Manages movement,
%                object detection, A* navigation, pushing logic, and visualization.
% Inputs       : None
% Outputs      : None
% ---------------------------------------------------------------------------------------------
function Demo1()
    clear
    figure
    obj_pos = []; % Stores detected object positions
    pushed_objects = []; % Tracks objects that have already been pushed out
    clear robot_sim_server;

    visit_count = zeros(16,4); % Tracks number of visits per position per direction
    global_visit_count = zeros(16,1); % Tracks total visits per position

    persistent recent_positions % Used to detect if robot is stuck
    recent_positions = [];

    navigating_to_target = false; % Flag for A* navigation mode
    pushing_mode = false; % Flag for push mode
    step = 1; 
    move_counter = 0; 
    path = []; 
    target_idx = []; % Index of object being targeted for pushing
    skip_detection_cycles = 0; 
    last_pushed_pos = -1; % Position of last pushed object
    last_pushed_forward_pos = -1; % Position object was pushed into

    while true
        result = robot_sim_server("status"); % Get current position and direction
        pos = result(1);
        dir = result(2);

        robot_plot(pos, dir, obj_pos); % Visualize current state
        drawnow;
        pause(0.1)

        sensor_data = robot_sim_server("sensor_read"); % Read sensor inputs

        % Handle object pushing behavior
        if pushing_mode
            robot_sim_server("move 1"); % Push forward
            move_counter = move_counter + 1;
            pause(0.1);

            updated_status = robot_sim_server("status");
            if target_idx >= 1 && target_idx <= length(obj_pos)
                forward_pos = get_forward_position(obj_pos(target_idx), updated_status(2));

                % If object leaves grid, remove it
                if is_push_off_grid(obj_pos(target_idx), updated_status(2))
                    last_pushed_pos = obj_pos(target_idx);
                    last_pushed_forward_pos = forward_pos;
                    pushed_objects = [pushed_objects last_pushed_pos];
                    obj_pos(target_idx) = [];
                    disp("Object pushed out of grid and removed.");

                    robot_plot(updated_status(1), updated_status(2), obj_pos); % Final plot
                    drawnow;
                    pause(0.1);
                    fprintf("Total movements: %d\n", move_counter);
                    return;
                else
                    obj_pos(target_idx) = forward_pos; % Update object position
                end
            end
            continue;
        end

        % Follow A* path if navigating
        if navigating_to_target && step <= size(path, 1)
            [xNext, yNext] = deal(path(step,1), path(step,2));
            next_pos = (yNext - 1) * 4 + (xNext - 1);
            [target_dir, turn_cmd] = calculate_turn(pos, dir, next_pos);

            if target_dir == dir
                robot_sim_server("move 1");
                move_counter = move_counter + 1;
                updated_status = robot_sim_server("status");
                if updated_status(1) == next_pos
                    pos = next_pos;
                    step = step + 1;
                else
                    disp("Move failed, replanning.");
                    navigating_to_target = false;
                end
            else
                robot_sim_server("move " + turn_cmd);
                move_counter = move_counter + 1;
                dir = mod(dir + (turn_cmd == 0) - (turn_cmd == 2), 4);
            end
            continue;
        elseif navigating_to_target
            navigating_to_target = false;
            if target_idx >= 1 && target_idx <= length(obj_pos) && pos == obj_pos(target_idx)
                pushing_mode = true; % Begin pushing if target reached
            else
                disp("Target not reached, cancelling push.");
                path = [];
                target_idx = [];
            end
            continue;
        end

        % Determine if move is within grid bounds
        row = floor(pos / 4);
        col = mod(pos, 4);
        canMove = true;
        switch dir
            case 0, if row == 3, canMove = false; end
            case 1, if col == 0, canMove = false; end
            case 2, if row == 0, canMove = false; end
            case 3, if col == 3, canMove = false; end
        end

        visit_count(pos +1, dir +1) = visit_count(pos + 1, dir + 1) + 1;
        stuck = visit_count(pos + 1, dir + 1) >= 3;
        global_visit_count(pos + 1) = global_visit_count(pos + 1) + 1;

        recent_positions = [recent_positions pos];
        if length(recent_positions) > 5
            recent_positions = recent_positions(end-4:end);
        end
        is_really_stuck = length(unique(recent_positions)) == 1;

        % Decide movement based on sensors and visit count
        forward_pos = get_forward_position(pos, dir);
        if canMove && length(sensor_data) >= 2 && sensor_data(2) == 0
            if global_visit_count(forward_pos + 1) < 2 || is_really_stuck
                robot_sim_server("move 1");
                move_counter = move_counter + 1;
            else
                robot_sim_server("move 2");
                move_counter = move_counter + 1;
            end
        else
            if stuck
                robot_sim_server("move 0");
                move_counter = move_counter + 1;
                visit_count(pos + 1, dir + 1) = 0;
            else
                robot_sim_server("move 2");
                move_counter = move_counter + 1;
            end
        end

        % Delay further detection during special modes
        if skip_detection_cycles > 0 || navigating_to_target || pushing_mode
            skip_detection_cycles = skip_detection_cycles - 1;
            continue;
        end

        % Detect objects from sensor data
        for i = 1:min(3, length(sensor_data))
            if sensor_data(i) == 1
                new_pos = pos;
                switch dir
                    case 0
                        if i == 1, new_pos = pos-1;
                        elseif i == 2, new_pos = pos+4;
                        elseif i == 3, new_pos = pos+1; end
                    case 1
                        if i == 1, new_pos = pos-4;
                        elseif i == 2, new_pos = pos-1;
                        elseif i == 3, new_pos = pos+4; end
                    case 2
                        if i == 1, new_pos = pos+1;
                        elseif i == 2, new_pos = pos-4;
                        elseif i == 3, new_pos = pos-1; end
                    case 3
                        if i == 1, new_pos = pos+4;
                        elseif i == 2, new_pos = pos+1;
                        elseif i == 3, new_pos = pos-4; end
                end
                if new_pos >= 0 && new_pos <= 15 ...
                    && ~ismember(new_pos, obj_pos) ...
                    && ~ismember(new_pos, pushed_objects) ...
                    && new_pos ~= pos
                    fprintf("Detected new object at %d\n", new_pos);
                    obj_pos = [obj_pos new_pos];
                end
            end
        end

        % When all objects found, calculate distances and start A*
        if length(obj_pos) == 4 && ~navigating_to_target && ~pushing_mode
            disp("----- Object Distance Sums (SOD) -----")
            n = length(obj_pos);
            SOD = zeros(n, 1);
            for i = 1:n
                [x1, y1] = position_to_xy(obj_pos(i));
                sum_dist = 0;
                for j = 1:n
                    if i ~= j
                        [x2, y2] = position_to_xy(obj_pos(j));
                        sum_dist = sum_dist + distance(x1, y1, x2, y2);
                    end
                end
                SOD(i) = sum_dist;
                fprintf("Obj%d at pos %d: SOD = %.3f\n", i, obj_pos(i), sum_dist);
            end
            [~, sorted_idx] = sort(SOD, 'descend');
            for i = 1:n
                idx = sorted_idx(i);
                [xStart, yStart] = position_to_xy(pos);
                [xGoal, yGoal] = position_to_xy(obj_pos(idx));
                temp_obs = obj_pos; temp_obs(idx) = []; % exclude target from obstacles
                path = astar_path(xStart, yStart, xGoal, yGoal, temp_obs);
                if ~isempty(path)
                    fprintf("Navigating to Obj%d at pos %d\n", idx, obj_pos(idx));
                    disp("A* path:");
                    disp(path);
                    step = 2;
                    navigating_to_target = true;
                    target_idx = idx;
                    break;
                end
            end
        end
    end
end

% ---------------------------------------------------------------------------------------------
% Function     : get_forward_position
% Purpose      : Computes the next position in front of the robot based on its direction.
% Inputs       : pos - current linear position (0 to 15)
%                dir - current direction (0: up, 1: left, 2: down, 3: right)
% Output       : next_pos - forward position index
% ---------------------------------------------------------------------------------------------
function next_pos = get_forward_position(pos, dir)
    switch dir
        case 0, next_pos = pos + 4;
        case 1, next_pos = pos - 1;
        case 2, next_pos = pos - 4;
        case 3, next_pos = pos + 1;
    end
end

% ---------------------------------------------------------------------------------------------
% Function     : position_to_xy
% Purpose      : Converts a linear index into (x, y) grid coordinates.
% Input        : pos - linear grid index (0 to 15)
% Output       : x, y - grid coordinates
% ---------------------------------------------------------------------------------------------
function [x, y] = position_to_xy(pos)
    x = mod(pos, 4) + 1;
    y = floor(pos / 4) + 1;
end

% ---------------------------------------------------------------------------------------------
% Function     : calculate_turn
% Purpose      : Determines the direction to face and the turn command to reach
%                the next desired position.
% Inputs       : pos - current position
%                current_dir - current facing direction
%                next_pos - target position to move to
% Outputs      : target_dir - required facing direction
%                turn_cmd - turn command (0: left, 1: forward, 2: right)
% ---------------------------------------------------------------------------------------------
function [target_dir, turn_cmd] = calculate_turn(pos, current_dir, next_pos)
    delta = next_pos - pos;
    switch delta
        case 1, target_dir = 3;
        case -1, target_dir = 1;
        case 4, target_dir = 0;
        case -4, target_dir = 2;
        otherwise, target_dir = current_dir;
    end
    diff = mod(target_dir - current_dir, 4);
    switch diff
        case 0, turn_cmd = 1;
        case 1, turn_cmd = 0;
        case 2, turn_cmd = 0;
        case 3, turn_cmd = 2;
    end
end

% ---------------------------------------------------------------------------------------------
% Function     : distance
% Purpose      : Calculates the Euclidean distance between two grid coordinates.
% Inputs       : x1, y1 - coordinates of first point
%                x2, y2 - coordinates of second point
% Output       : dist - Euclidean distance
% ---------------------------------------------------------------------------------------------
function dist = distance(x1, y1, x2, y2)
    dist = sqrt((x1 - x2)^2 + (y1 - y2)^2);
end

% ---------------------------------------------------------------------------------------------
% Function     : is_push_off_grid
% Purpose      : Determines if an object would be pushed off the grid in the given direction.
% Inputs       : pos - object's current position
%                dir - direction of push
% Output       : at_edge - boolean indicating whether the push will remove the object
% ---------------------------------------------------------------------------------------------
function at_edge = is_push_off_grid(pos, dir)
    row = floor(pos / 4);
    col = mod(pos, 4);
    switch dir
        case 0, at_edge = row == 3;
        case 1, at_edge = col == 0;
        case 2, at_edge = row == 0;
        case 3, at_edge = col == 3;
        otherwise, at_edge = false;
    end
end
