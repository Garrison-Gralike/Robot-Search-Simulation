function Optimal_path = astar_path(xStart, yStart, xGoal, yGoal, obstacle_list)
% astar_path: Computes path from (xStart, yStart) to (xGoal, yGoal)
% using A* algorithm on a 4x4 grid with 4-point connectivity
% Input/Output positions are 1-based (1 to 4)
% Output: Optimal_path as N x 2 matrix [x y]

MAX_X = 4;
MAX_Y = 4;

MAP = 2 * ones(MAX_X, MAX_Y);  % 2 = empty
MAP(xGoal, yGoal) = 0;         % 0 = target


% Mark obstacles but skip the goal cell
for i = 1:length(obstacle_list)
    [ox, oy] = position_to_xy(obstacle_list(i));
    if ox == xGoal && oy == yGoal
        continue;  % 
    end
    MAP(ox, oy) = -1;
end

% Initialize lists
OPEN = [];
CLOSED = [];

% Add all obstacles to CLOSED list
k = 1;
for i = 1:MAX_X
    for j = 1:MAX_Y
        if MAP(i,j) == -1
            CLOSED(k,:) = [i j];
            k = k + 1;
        end
    end
end

% Add start node to OPEN list
path_cost = 0;
goal_distance = distance(xStart, yStart, xGoal, yGoal);
OPEN(1,:) = insert_open(xStart, yStart, xStart, yStart, goal_distance, path_cost, path_cost + goal_distance);
OPEN(1,1) = 0; % not visited yet
CLOSED = [CLOSED; xStart yStart];

xNode = xStart;
yNode = yStart;
NoPath = 1;
OPEN_COUNT = 1;
CLOSED_COUNT = size(CLOSED,1);

while ((xNode ~= xGoal || yNode ~= yGoal) && NoPath == 1)
    exp_array = expand_array(xNode, yNode, path_cost, xGoal, yGoal, CLOSED, MAX_X, MAX_Y);
    exp_count = size(exp_array, 1);

    for i = 1:exp_count
        flag = 0;
        for j = 1:OPEN_COUNT
            if exp_array(i,1) == OPEN(j,2) && exp_array(i,2) == OPEN(j,3)
                if OPEN(j,8) > exp_array(i,5)
                    OPEN(j,4:8) = [xNode, yNode, exp_array(i,3:5)];
                end
                flag = 1;
                break;
            end
        end
        if flag == 0
            OPEN_COUNT = OPEN_COUNT + 1;
            OPEN(OPEN_COUNT,:) = insert_open(exp_array(i,1), exp_array(i,2), xNode, yNode, ...
                                              exp_array(i,3), exp_array(i,4), exp_array(i,5));
        end
    end

    index_min_node = min_fn(OPEN, OPEN_COUNT, xGoal, yGoal);
    if index_min_node == -1
        NoPath = 0;
        break;
    end

    xNode = OPEN(index_min_node,2);
    yNode = OPEN(index_min_node,3);
    path_cost = OPEN(index_min_node,7);
    CLOSED = [CLOSED; xNode yNode];
    OPEN(index_min_node,1) = 0;
end

% Reconstruct path
Optimal_path = [];
if xNode == xGoal && yNode == yGoal
    parent_x = OPEN(index_min_node,4);
    parent_y = OPEN(index_min_node,5);
    Optimal_path = [xGoal, yGoal];

    while ~(parent_x == xStart && parent_y == yStart)
        Optimal_path = [parent_x, parent_y; Optimal_path];
        idx = node_index(OPEN, parent_x, parent_y);
        parent_x = OPEN(idx,4);
        parent_y = OPEN(idx,5);
    end

    Optimal_path = [xStart, yStart; Optimal_path];
else
    disp('No path found!');
end
end
