function [x, y] = position_to_xy(pos)
    x = mod(pos, 4) + 1;        % column (1-based)
    y = floor(pos / 4) + 1;     % row (1-based)
end
